# API 文档

## 搜索API

### 搜索论文
```python
from scripts.search_arxiv import search_arxiv

# 基本搜索
results = search_arxiv("machine learning", max_results=10)

# 高级搜索
results = search_arxiv(
    query="cat:cs.LG",
    max_results=20,
    sort_by="submittedDate",
    sort_order="descending"
)
```

### 获取引用
```python
from scripts.get_bibtex import get_bibtex_from_arxiv

# 获取BibTeX
bibtex = get_bibtex_from_arxiv("2402.04557v1")
print(bibtex)
```

## 命令行接口

### search_arxiv.py
```bash
# 基本用法
python3 scripts/search_arxiv.py --query "deep learning"

# 所有选项
python3 scripts/search_arxiv.py --help
```

### get_bibtex.py
```bash
# 通过arXiv ID获取
python3 scripts/get_bibtex.py --arxiv "2402.04557v1"

# 通过DOI获取
python3 scripts/get_bibtex.py --doi "10.1038/s41586-021-03819-2"
```
