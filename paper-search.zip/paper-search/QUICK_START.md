# 快速开始指南

## 🚀 5分钟快速发布到GitHub

### 步骤1: 准备环境
```bash
# 1. 进入技能目录
cd /Users/jiangyi/.openclaw/workspace/skills/paper-search

# 2. 确保有GitHub账号
# 如果没有，请先注册: https://github.com

# 3. 安装GitHub CLI (可选但推荐)
# macOS: brew install gh
# 其他系统: https://cli.github.com
```

### 步骤2: 运行发布脚本
```bash
# 运行自动化发布脚本
./publish_to_github.sh
```

### 步骤3: 按照提示操作
脚本会引导你完成：
1. ✅ 环境检查
2. ✅ 技能结构验证
3. ✅ 运行测试
4. ✅ 初始化Git仓库
5. 🔧 配置GitHub仓库（需要输入信息）
6. 🎉 创建GitHub Release

### 步骤4: 完成发布
脚本完成后，你的技能就已经发布到GitHub了！

## 📦 手动发布步骤（如果不使用脚本）

### 1. 初始化Git仓库
```bash
cd /Users/jiangyi/.openclaw/workspace/skills/paper-search
git init
git add .
git commit -m "Initial commit: paper-search skill v1.0.0"
```

### 2. 在GitHub创建仓库
1. 访问 https://github.com/new
2. 填写仓库信息：
   - Repository name: `paper-search`
   - Description: `OpenClaw paper search skill`
   - 选择公开(Public)或私有(Private)
   - 不要初始化README（我们已经有了）

### 3. 连接到GitHub
```bash
# 添加远程仓库（替换YOUR_USERNAME）
git remote add origin https://github.com/YOUR_USERNAME/paper-search.git

# 推送代码
git branch -M main
git push -u origin main
```

### 4. 创建Release
1. 在GitHub仓库页面点击"Create a new release"
2. 填写版本号: `v1.0.0`
3. 标题: `paper-search v1.0.0`
4. 描述: 复制下面的发布说明
5. 上传发布包: `paper-search-v1.0.0.tar.gz`

## 📝 发布说明模板

```markdown
## paper-search v1.0.0

### 🎉 初始版本发布

一个强大的学术论文搜索和文献管理工具，专为OpenClaw设计。

### ✨ 功能特性
- 🔍 arXiv论文搜索（支持高级语法）
- 📚 自动BibTeX引用生成
- 📊 多种输出格式（Text/JSON/Markdown）
- 🎯 智能搜索和筛选
- 🔄 批量处理和自动化

### 🚀 快速开始
```bash
# 安装
cp -r paper-search /path/to/openclaw/skills/

# 搜索论文
python3 scripts/search_arxiv.py --query "machine learning"

# 获取引用
python3 scripts/get_bibtex.py --arxiv "2402.04557v1"
```

### 📖 文档
- [详细使用指南](README.md)
- [API参考](references/api_reference.md)
- [使用示例](examples/)

### 🛠 技术栈
- Python 3.7+
- arXiv API
- Crossref API

### 📄 许可证
MIT License
```

## 🔧 创建发布包
```bash
# 创建压缩包（排除.git等文件）
tar -czf paper-search-v1.0.0.tar.gz \
  --exclude=".git" \
  --exclude=".DS_Store" \
  --exclude="*.pyc" \
  --exclude="__pycache__" \
  .
```

## 🌐 分享到社区

### 1. OpenClaw社区
- Discord: https://discord.gg/clawd
- 在`#skills`频道分享你的技能

### 2. ClawHub
```bash
# 准备ClawHub发布
# 1. 访问 https://clawhub.com
# 2. 点击"发布新技能"
# 3. 上传你的技能包
# 4. 填写技能信息
```

### 3. 社交媒体
- Twitter/X: 使用标签 `#OpenClaw` `#AI`
- 技术博客: 写一篇使用教程
- 学术社区: 分享给同学和同事

## 🆘 常见问题

### Q: GitHub CLI安装失败？
A: 可以手动使用GitHub网页界面创建仓库，然后使用git命令推送。

### Q: 脚本运行出错？
A: 检查：
1. 是否在正确的目录运行
2. 是否有网络连接
3. Python和Git是否已安装

### Q: 如何更新版本？
A: 修改版本号后重新运行发布脚本，或手动创建新Release。

### Q: 想要更多功能？
A: 欢迎提交Issue或Pull Request！

## 📞 支持

- GitHub Issues: 报告问题
- Email: 你的邮箱
- OpenClaw社区: 寻求帮助

---

**现在就开始发布吧！** 🚀

你的技能将帮助无数科研工作者和学生更高效地进行文献调研！