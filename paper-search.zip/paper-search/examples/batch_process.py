#!/usr/bin/env python3
"""
批量处理示例
演示如何批量搜索和处理论文
"""

import sys
import os
import json
import time
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.search_arxiv import search_arxiv
from scripts.get_bibtex import get_bibtex_from_arxiv

def batch_search_topics():
    """批量搜索多个主题"""
    print("=== 批量搜索多个主题 ===")
    
    # 定义要搜索的主题列表
    topics = [
        "machine learning",
        "deep learning", 
        "natural language processing",
        "computer vision",
        "reinforcement learning"
    ]
    
    all_results = {}
    
    for topic in topics:
        print(f"\n搜索主题: {topic}")
        
        try:
            # 搜索每个主题
            results = search_arxiv(
                query=topic,
                max_results=3,
                sort_by="submittedDate",
                sort_order="descending"
            )
            
            all_results[topic] = results
            
            # 显示结果
            print(f"  找到 {len(results)} 篇论文")
            for i, paper in enumerate(results, 1):
                print(f"  {i}. {paper.get('title', 'N/A')[:60]}...")
                
            # 避免请求过于频繁
            time.sleep(1)
            
        except Exception as e:
            print(f"  搜索失败: {e}")
    
    return all_results

def generate_bibtex_for_papers(papers_dict):
    """为论文生成BibTeX引用"""
    print("\n=== 生成BibTeX引用 ===")
    
    bibtex_entries = []
    
    for topic, papers in papers_dict.items():
        print(f"\n处理主题: {topic}")
        
        for paper in papers:
            arxiv_id = paper.get('id', '').replace('http://arxiv.org/abs/', '')
            if arxiv_id:
                try:
                    print(f"  获取论文: {arxiv_id}")
                    bibtex = get_bibtex_from_arxiv(arxiv_id)
                    if bibtex:
                        bibtex_entries.append(bibtex)
                        print(f"    ✓ 成功获取")
                    else:
                        print(f"    ✗ 获取失败")
                    
                    # 避免请求过于频繁
                    time.sleep(0.5)
                    
                except Exception as e:
                    print(f"    ✗ 错误: {e}")
    
    return bibtex_entries

def save_results(all_results, bibtex_entries):
    """保存结果到文件"""
    print("\n=== 保存结果 ===")
    
    # 创建输出目录
    output_dir = "output"
    os.makedirs(output_dir, exist_ok=True)
    
    # 保存搜索结果为JSON
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_file = os.path.join(output_dir, f"search_results_{timestamp}.json")
    
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    
    print(f"搜索结果已保存到: {json_file}")
    
    # 保存BibTeX引用
    if bibtex_entries:
        bibtex_file = os.path.join(output_dir, f"references_{timestamp}.bib")
        
        with open(bibtex_file, 'w', encoding='utf-8') as f:
            for entry in bibtex_entries:
                f.write(entry + "\n\n")
        
        print(f"BibTeX引用已保存到: {bibtex_file}")
    
    # 生成Markdown报告
    markdown_file = os.path.join(output_dir, f"report_{timestamp}.md")
    
    with open(markdown_file, 'w', encoding='utf-8') as f:
        f.write(f"# 论文搜索报告\n\n")
        f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        for topic, papers in all_results.items():
            f.write(f"## {topic}\n\n")
            f.write(f"找到 {len(papers)} 篇论文\n\n")
            
            for i, paper in enumerate(papers, 1):
                f.write(f"### {i}. {paper.get('title', 'N/A')}\n\n")
                f.write(f"- **作者**: {', '.join(paper.get('authors', []))}\n")
                f.write(f"- **发布日期**: {paper.get('published', 'N/A')}\n")
                f.write(f"- **arXiv ID**: {paper.get('id', 'N/A')}\n")
                f.write(f"- **分类**: {', '.join(paper.get('categories', []))}\n")
                f.write(f"- **摘要**: {paper.get('summary', 'N/A')[:200]}...\n\n")
    
    print(f"Markdown报告已保存到: {markdown_file}")
    
    return {
        'json': json_file,
        'bibtex': bibtex_file if bibtex_entries else None,
        'markdown': markdown_file
    }

def main():
    """主函数"""
    print("批量处理示例")
    print("=" * 50)
    
    try:
        # 1. 批量搜索
        print("开始批量搜索...")
        all_results = batch_search_topics()
        
        # 2. 生成BibTeX
        print("\n开始生成BibTeX引用...")
        bibtex_entries = generate_bibtex_for_papers(all_results)
        
        # 3. 保存结果
        print("\n开始保存结果...")
        saved_files = save_results(all_results, bibtex_entries)
        
        # 4. 总结
        print("\n" + "=" * 50)
        print("批量处理完成！")
        print(f"总计搜索主题: {len(all_results)}")
        
        total_papers = sum(len(papers) for papers in all_results.values())
        print(f"总计找到论文: {total_papers}")
        print(f"生成BibTeX引用: {len(bibtex_entries)}")
        
        print("\n生成的文件:")
        for file_type, file_path in saved_files.items():
            if file_path:
                print(f"  {file_type}: {file_path}")
                
    except Exception as e:
        print(f"处理过程中发生错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()