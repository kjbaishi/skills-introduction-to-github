#!/usr/bin/env python3
"""
基础搜索示例
演示如何使用paper-search技能进行基本搜索
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.search_arxiv import search_arxiv, parse_arguments

def example_basic_search():
    """基础搜索示例"""
    print("=== 基础搜索示例 ===")
    
    # 示例1: 搜索机器学习相关论文
    print("\n1. 搜索机器学习相关论文:")
    results = search_arxiv(
        query="machine learning",
        max_results=3,
        sort_by="submittedDate",
        sort_order="descending"
    )
    
    for i, paper in enumerate(results, 1):
        print(f"\n论文 #{i}:")
        print(f"  标题: {paper.get('title', 'N/A')}")
        print(f"  作者: {', '.join(paper.get('authors', []))}")
        print(f"  发布日期: {paper.get('published', 'N/A')}")
        print(f"  arXiv ID: {paper.get('id', 'N/A')}")
    
    # 示例2: 按分类搜索
    print("\n\n2. 按分类搜索（计算机科学-机器学习）:")
    results = search_arxiv(
        query="cat:cs.LG",
        max_results=2
    )
    
    for i, paper in enumerate(results, 1):
        print(f"\n论文 #{i}:")
        print(f"  标题: {paper.get('title', 'N/A')}")
        print(f"  分类: {', '.join(paper.get('categories', []))}")
    
    # 示例3: 组合搜索
    print("\n\n3. 组合搜索（深度学习+计算机视觉）:")
    results = search_arxiv(
        query="deep learning AND computer vision",
        max_results=2
    )
    
    for i, paper in enumerate(results, 1):
        print(f"\n论文 #{i}:")
        print(f"  标题: {paper.get('title', 'N/A')}")
        print(f"  摘要（前100字符）: {paper.get('summary', 'N/A')[:100]}...")

def example_command_line():
    """命令行使用示例"""
    print("\n=== 命令行使用示例 ===")
    print("\n1. 基本搜索:")
    print("   python3 scripts/search_arxiv.py --query \"machine learning\" --max-results 5")
    
    print("\n2. 按分类搜索:")
    print("   python3 scripts/search_arxiv.py --query \"cat:cs.LG\" --max-results 10")
    
    print("\n3. 按日期排序:")
    print("   python3 scripts/search_arxiv.py --query \"AI\" --sort-by submittedDate --sort-order descending")
    
    print("\n4. 输出JSON格式:")
    print("   python3 scripts/search_arxiv.py --query \"quantum computing\" --format json > results.json")
    
    print("\n5. 输出Markdown格式:")
    print("   python3 scripts/search_arxiv.py --query \"neural networks\" --format markdown > papers.md")

def main():
    """主函数"""
    print("paper-search 技能使用示例")
    print("=" * 50)
    
    example_basic_search()
    example_command_line()
    
    print("\n" + "=" * 50)
    print("示例完成！更多用法请参考 README.md")

if __name__ == "__main__":
    main()