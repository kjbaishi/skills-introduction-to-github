# arXiv API 使用指南

## 概述

arXiv API 允许程序化访问 arXiv 预印本服务器的内容。这是一个公开的、无需认证的API。

## 基础查询

### API端点
```
http://export.arxiv.org/api/query
```

### 基本参数
- `search_query`: 搜索查询字符串
- `start`: 起始位置 (0-based)
- `max_results`: 返回的最大结果数 (默认10，最大30000)
- `sortBy`: 排序方式 (`relevance`, `lastUpdatedDate`, `submittedDate`)
- `sortOrder`: 排序顺序 (`ascending`, `descending`)

## 搜索查询语法

### 基本搜索
- `ti:` - 标题
- `au:` - 作者
- `abs:` - 摘要
- `co:` - 评论
- `jr:` - 期刊引用
- `cat:` - 分类
- `rn:` - 报告编号
- `id:` - arXiv ID
- `all:` - 所有字段

### 布尔运算符
- `AND` (默认): `machine AND learning`
- `OR`: `neural OR network`
- `ANDNOT`: `quantum ANDNOT computing`
- 括号分组: `(deep OR convolutional) AND network`

### 分类搜索
arXiv使用分类系统，例如：
- `cs.LG` - 机器学习
- `cs.AI` - 人工智能
- `cs.CV` - 计算机视觉
- `physics.chem-ph` - 化学物理
- `cond-mat.mtrl-sci` - 材料科学

完整分类列表: https://arxiv.org/category_taxonomy

## 示例查询

### 搜索机器学习相关论文
```
search_query=all:machine+learning
```

### 搜索特定作者的论文
```
search_query=au:"Yann+LeCun"
```

### 搜索特定分类的论文
```
search_query=cat:cs.LG
```

### 组合查询
```
search_query=ti:"transformer"+AND+cat:cs.LG
```

## 响应格式

API返回Atom格式的XML响应。主要字段包括：

### 每个条目 (entry) 包含：
- `id`: arXiv ID和URL
- `title`: 论文标题
- `summary`: 摘要
- `author`: 作者列表 (每个作者有name元素)
- `category`: 分类列表 (每个分类有term属性)
- `published`: 首次发布日期
- `updated`: 最后更新日期
- `link`: 相关链接 (PDF, abstract等)

### 命名空间
- Atom命名空间: `http://www.w3.org/2005/Atom`
- arXiv命名空间: `http://arxiv.org/schemas/atom`

## 使用限制

### 频率限制
- 每IP地址：最多每秒1个请求
- 建议：在请求之间添加延迟 (至少1秒)

### 结果限制
- 单次查询最多返回30000条结果
- 如果结果超过限制，需要分页查询

### 礼貌使用
- 避免过度频繁的查询
- 缓存结果以减少API调用
- 在非高峰时段进行批量查询

## 错误处理

### 常见错误
- `400 Bad Request`: 查询语法错误
- `403 Forbidden`: 频率限制
- `500 Internal Server Error`: 服务器问题

### 重试策略
- 遇到429或5xx错误时等待重试
- 实现指数退避算法
- 记录失败查询以便调试

## 最佳实践

### 1. 分页查询
对于大量结果，使用分页：
```python
start = 0
max_results = 100
while True:
    query = f"search_query=all:machine+learning&start={start}&max_results={max_results}"
    # 执行查询
    start += max_results
    if no_more_results:
        break
```

### 2. 缓存结果
缓存频繁查询的结果，减少API调用。

### 3. 用户代理
设置合适的User-Agent头部：
```python
headers = {
    'User-Agent': 'YourAppName/1.0 (your-email@example.com)'
}
```

### 4. 错误日志
记录失败的查询和错误信息，便于调试。

## 高级功能

### 批量ID查询
通过ID列表查询多个论文：
```
id_list=2101.12345,2101.12346,2101.12347
```

### 时间范围查询
虽然API不直接支持时间范围，但可以通过排序和过滤实现。

### 自定义输出
API只返回Atom格式，需要在客户端进行格式转换。

## 相关资源

- 官方文档: https://arxiv.org/help/api
- 分类系统: https://arxiv.org/category_taxonomy
- 用户论坛: https://groups.google.com/g/arxiv-api

## 注意事项

1. **数据新鲜度**: arXiv是预印本服务器，论文可能被更新或撤回
2. **版权**: 遵守arXiv的使用条款和版权声明
3. **引用**: 使用arXiv内容时正确引用
4. **完整性**: API可能不包含所有元数据字段