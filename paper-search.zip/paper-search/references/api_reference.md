# API 参考文档

## arXiv API

### 基础URL
```
http://export.arxiv.org/api/query
```

### 查询参数

| 参数 | 描述 | 示例 | 默认值 |
|------|------|------|--------|
| `search_query` | 搜索查询 | `all:electron` | 必填 |
| `id_list` | arXiv ID列表 | `1234.56789,9876.54321` | 无 |
| `start` | 起始位置 | `0` | `0` |
| `max_results` | 最大结果数 | `10` | `10` |
| `sortBy` | 排序方式 | `relevance`, `lastUpdatedDate`, `submittedDate` | `relevance` |
| `sortOrder` | 排序顺序 | `ascending`, `descending` | `descending` |

### 搜索查询语法

#### 基本搜索
```
all:keyword
```

#### 字段搜索
```
ti:title          # 标题
au:author         # 作者
abs:abstract      # 摘要
co:comment        # 评论
cat:category      # 分类
```

#### 逻辑运算符
```
AND               # 与
OR                # 或
ANDNOT            # 非
```

#### 分类代码
```
cs.AI             # 人工智能
cs.LG             # 机器学习
cs.CV             # 计算机视觉
cs.CL             # 计算语言学
physics.chem-ph   # 化学物理
math.NA           # 数值分析
```

#### 示例查询
```bash
# 标题包含"machine learning"
ti:machine AND ti:learning

# 作者为"John Smith"
au:John AND au:Smith

# 计算机视觉或图像处理
cat:cs.CV OR abs:"image processing"

# 排除特定分类
all:quantum ANDNOT cat:quant-ph
```

### 响应格式

#### XML格式示例
```xml
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <title>Paper Title</title>
    <id>http://arxiv.org/abs/1234.56789v1</id>
    <published>2024-01-01T00:00:00Z</published>
    <updated>2024-01-02T00:00:00Z</updated>
    <summary>Paper abstract...</summary>
    <author>
      <name>Author Name</name>
    </author>
    <link href="http://arxiv.org/abs/1234.56789v1" rel="alternate"/>
    <link title="pdf" href="http://arxiv.org/pdf/1234.56789v1.pdf" rel="related"/>
    <category term="cs.LG" scheme="http://arxiv.org/schemas/atom"/>
  </entry>
</feed>
```

## Crossref API

### 基础URL
```
https://api.crossref.org/works/{DOI}
```

### 请求头
```http
Accept: application/vnd.citationstyles.csl+json
User-Agent: YourApp/1.0 (mailto:your@email.com)
```

### 响应格式（CSL-JSON）
```json
{
  "DOI": "10.1038/s41586-021-03819-2",
  "title": "Paper Title",
  "author": [
    {
      "given": "John",
      "family": "Doe"
    }
  ],
  "issued": {
    "date-parts": [[2021, 1, 1]]
  },
  "container-title": "Nature",
  "volume": "589",
  "issue": "7841",
  "page": "1-10",
  "URL": "https://doi.org/10.1038/s41586-021-03819-2"
}
```

## BibTeX 格式

### 基本结构
```bibtex
@article{citation_key,
  title = {Paper Title},
  author = {Author One and Author Two},
  journal = {Journal Name},
  year = {2024},
  volume = {123},
  pages = {1--10},
  doi = {10.1234/example}
}
```

### 条目类型

| 类型 | 描述 | 示例 |
|------|------|------|
| `@article` | 期刊文章 | 学术论文 |
| `@inproceedings` | 会议论文 | 会议发表 |
| `@book` | 书籍 | 专著 |
| `@phdthesis` | 博士论文 | 学位论文 |
| `@mastersthesis` | 硕士论文 | 学位论文 |
| `@techreport` | 技术报告 | 研究报告 |
| `@misc` | 其他 | 网页、软件等 |

### 常用字段

| 字段 | 描述 | 必需 |
|------|------|------|
| `title` | 标题 | 是 |
| `author` | 作者 | 是 |
| `year` | 年份 | 是 |
| `journal` | 期刊名 | 文章需要 |
| `booktitle` | 会议/书名 | 会议/书需要 |
| `publisher` | 出版社 | 书需要 |
| `volume` | 卷号 | 可选 |
| `number` | 期号 | 可选 |
| `pages` | 页码 | 可选 |
| `doi` | DOI | 可选 |
| `url` | URL | 可选 |
| `arxiv` | arXiv ID | 可选 |

## 错误处理

### HTTP状态码

| 代码 | 描述 | 处理建议 |
|------|------|----------|
| 200 | 成功 | 正常处理响应 |
| 400 | 错误请求 | 检查查询参数 |
| 403 | 禁止访问 | 检查API密钥或限制 |
| 404 | 未找到 | 检查ID或URL |
| 429 | 请求过多 | 降低请求频率 |
| 500 | 服务器错误 | 稍后重试 |

### 常见错误

```python
# arXiv API错误示例
try:
    response = requests.get(ARXIV_API_URL, params=params, timeout=10)
    response.raise_for_status()
except requests.exceptions.HTTPError as e:
    if response.status_code == 429:
        print("请求过于频繁，请稍后重试")
        time.sleep(60)  # 等待1分钟
    else:
        print(f"HTTP错误: {e}")
except requests.exceptions.Timeout:
    print("请求超时")
except requests.exceptions.RequestException as e:
    print(f"请求异常: {e}")
```

## 速率限制

### arXiv API
- 最大结果数：1000条/请求
- 请求频率：建议每秒不超过1次
- 实际限制：未明确说明，但应避免频繁请求

### Crossref API
- 免费用户：50次请求/秒
- Polite用户：100次请求/秒（需设置User-Agent）
- 商业用户：根据协议确定

### 最佳实践
```python
import time

def make_request_with_backoff(url, params, max_retries=3):
    """带退避机制的请求函数"""
    for attempt in range(max_retries):
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response
        except requests.exceptions.HTTPError as e:
            if response.status_code == 429:
                wait_time = 2 ** attempt  # 指数退避
                print(f"速率限制，等待 {wait_time} 秒后重试...")
                time.sleep(wait_time)
            else:
                raise e
        except requests.exceptions.RequestException as e:
            if attempt == max_retries - 1:
                raise e
            wait_time = 1 * (attempt + 1)
            print(f"请求失败，等待 {wait_time} 秒后重试...")
            time.sleep(wait_time)
    
    return None
```

## 数据转换

### XML转JSON
```python
import xml.etree.ElementTree as ET
import json

def xml_to_json(xml_content):
    """将arXiv XML响应转换为JSON"""
    root = ET.fromstring(xml_content)
    papers = []
    
    for entry in root.findall('{http://www.w3.org/2005/Atom}entry'):
        paper = {
            'title': entry.find('{http://www.w3.org/2005/Atom}title').text,
            'id': entry.find('{http://www.w3.org/2005/Atom}id').text,
            'published': entry.find('{http://www.w3.org/2005/Atom}published').text,
            'summary': entry.find('{http://www.w3.org/2005/Atom}summary').text,
            'authors': [author.find('{http://www.w3.org/2005/Atom}name').text 
                       for author in entry.findall('{http://www.w3.org/2005/Atom}author')],
            'categories': [cat.get('term') 
                          for cat in entry.findall('{http://www.w3.org/2005/Atom}category')]
        }
        papers.append(paper)
    
    return papers
```

### CSL-JSON转BibTeX
```python
def csl_to_bibtex(csl_data):
    """将CSL-JSON数据转换为BibTeX"""
    authors = ' and '.join([f"{author.get('family', '')}, {author.get('given', '')}" 
                           for author in csl_data.get('author', [])])
    
    bibtex = f"""@article{{{csl_data.get('DOI', '').replace('/', '_')},
  title = {{{csl_data.get('title', '')}}},
  author = {{{authors}}},
  journal = {{{csl_data.get('container-title', '')}}},
  year = {{{csl_data.get('issued', {}).get('date-parts', [[0]])[0][0]}}},
  volume = {{{csl_data.get('volume', '')}}},
  pages = {{{csl_data.get('page', '')}}},
  doi = {{{csl_data.get('DOI', '')}}},
  url = {{{csl_data.get('URL', '')}}}
}}"""
    
    return bibtex
```

## 更新日志

### v1.0.0 (2026-03-16)
- 初始API参考文档
- 包含arXiv和Crossref API文档
- 添加BibTeX格式说明
- 包含错误处理和速率限制指南