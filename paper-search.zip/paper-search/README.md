# paper-search -- OpenClaw学术论文搜索Skill

[![OpenClaw Skill](https://img.shields.io/badge/OpenClaw-Skill-blue)](https://clawhub.com)
[![Python 3.7+](https://img.shields.io/badge/python-3.7+-green.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

一个强大的学术论文搜索和文献管理工具，专为OpenClaw设计。支持arXiv、Google Scholar、PubMed等学术数据库的搜索和文献整理。

## ✨ 功能特性

- 🔍 **多数据库搜索**: 支持arXiv、Google Scholar、PubMed等
- 📚 **BibTeX生成**: 自动生成标准引用格式
- 📊 **结果导出**: 支持Text、JSON、Markdown多种格式
- 🎯 **智能筛选**: 按分类、日期、相关性排序
- 📈 **批量处理**: 支持批量搜索和结果整理
- 🔗 **链接解析**: 自动解析DOI和arXiv ID

## 🚀 快速开始

### 安装

1. 将本技能目录复制到OpenClaw的skills目录：
   ```bash
   cp -r paper-search /path/to/openclaw/skills/
   ```

2. 确保已安装Python 3.7+和依赖库：
   ```bash
   pip install requests
   ```

### 基本使用

#### arXiv搜索
```bash
cd /path/to/openclaw/skills/paper-search
python3 scripts/search_arxiv.py --query "machine learning" --max-results 10
```

#### 获取BibTeX引用
```bash
python3 scripts/get_bibtex.py --arxiv "2402.04557v1"
```

#### 整理搜索结果
```bash
python3 scripts/paper_organizer.py --input search_results.json --output organized.md
```

## 📖 详细使用指南

### 1. arXiv搜索

#### 基本搜索
```bash
python3 scripts/search_arxiv.py --query "deep learning" --max-results 5
```

#### 高级搜索选项
```bash
# 按分类搜索
python3 scripts/search_arxiv.py --query "cat:cs.LG AND machine learning" --max-results 8

# 按日期排序
python3 scripts/search_arxiv.py --query "quantum computing" --sort-by "submittedDate" --sort-order "descending"

# 分页搜索
python3 scripts/search_arxiv.py --query "neural networks" --start 20 --max-results 10
```

#### 输出格式
```bash
# 文本格式（默认）
python3 scripts/search_arxiv.py --query "AI" --format text

# JSON格式（便于程序处理）
python3 scripts/search_arxiv.py --query "AI" --format json > results.json

# Markdown格式（便于阅读）
python3 scripts/search_arxiv.py --query "AI" --format markdown > results.md
```

### 2. BibTeX引用管理

#### 通过arXiv ID获取
```bash
python3 scripts/get_bibtex.py --arxiv "2402.04557v1"
```

#### 通过DOI获取
```bash
python3 scripts/get_bibtex.py --doi "10.1038/s41586-021-03819-2"
```

#### 批量获取
```bash
# 从文件读取ID列表
python3 scripts/get_bibtex.py --input ids.txt --output references.bib
```

### 3. 论文整理

#### 整理搜索结果
```bash
python3 scripts/paper_organizer.py --input search_results.json --output organized.md
```

#### 生成阅读清单
```bash
python3 scripts/paper_organizer.py --input papers.json --format reading-list
```

## 🎯 应用场景

### 科研工作者
- 快速文献调研
- 跟踪研究前沿
- 管理参考文献
- 发现相关研究

### 学生
- 课程论文写作
- 毕业论文文献收集
- 学术研究入门
- 学习领域知识

### 开发者
- 技术调研
- 算法研究
- 开源项目参考
- 技术趋势分析

## 🔧 脚本说明

### `scripts/search_arxiv.py`
arXiv论文搜索脚本，支持高级搜索和多种输出格式。

**参数**:
- `--query`: 搜索查询（必填）
- `--max-results`: 最大结果数（默认10）
- `--start`: 起始位置（默认0）
- `--sort-by`: 排序方式（relevance/lastUpdatedDate/submittedDate）
- `--sort-order`: 排序顺序（ascending/descending）
- `--format`: 输出格式（text/json/markdown）

### `scripts/get_bibtex.py`
BibTeX引用生成脚本，支持arXiv ID和DOI。

**参数**:
- `--arxiv`: arXiv ID
- `--doi`: DOI
- `--identifier`: 自动检测标识符类型
- `--output`: 输出文件路径

### `scripts/paper_organizer.py`
论文整理脚本，支持多种整理方式。

**参数**:
- `--input`: 输入文件（JSON格式）
- `--output`: 输出文件路径
- `--format`: 输出格式（markdown/reading-list/bibtex）

## 📁 项目结构

```
paper-search/
├── SKILL.md              # OpenClaw技能描述文件
├── README.md             # 项目说明文档
├── LICENSE               # 许可证文件
├── requirements.txt      # Python依赖
├── scripts/              # 主要脚本
│   ├── search_arxiv.py   # arXiv搜索
│   ├── get_bibtex.py     # BibTeX生成
│   └── paper_organizer.py # 论文整理
├── examples/             # 使用示例
│   ├── basic_search.py   # 基础搜索示例
│   └── batch_process.py  # 批量处理示例
├── tests/                # 测试文件
│   ├── test_search.py    # 搜索测试
│   └── test_bibtex.py    # BibTeX测试
└── references/           # 参考文档
    ├── api_reference.md  # API参考
    └── best_practices.md # 最佳实践
```

## 🧪 示例

### 示例1：快速文献调研
```bash
# 搜索最新的人工智能论文
python3 scripts/search_arxiv.py \
  --query "artificial intelligence" \
  --max-results 10 \
  --sort-by "submittedDate" \
  --sort-order "descending" \
  --format markdown > ai_papers.md
```

### 示例2：生成参考文献
```bash
# 搜索并生成BibTeX
python3 scripts/search_arxiv.py \
  --query "cat:cs.LG AND transformer" \
  --max-results 5 \
  --format json > papers.json

# 提取arXiv ID并生成BibTeX
cat papers.json | jq -r '.[].id' | while read id; do
  python3 scripts/get_bibtex.py --arxiv "$id"
done > references.bib
```

### 示例3：批量处理
```bash
# 批量搜索多个主题
topics=("machine learning" "deep learning" "reinforcement learning")
for topic in "${topics[@]}"; do
  python3 scripts/search_arxiv.py \
    --query "$topic" \
    --max-results 5 \
    --format json > "${topic// /_}.json"
done
```

## ⚙️ 配置

### 环境变量
```bash
# 设置默认输出目录
export PAPER_SEARCH_OUTPUT_DIR="$HOME/Documents/papers"

# 设置默认搜索参数
export ARXIV_MAX_RESULTS=20
export ARXIV_SORT_BY="submittedDate"
```

### 配置文件
创建 `config.json`：
```json
{
  "arxiv": {
    "max_results": 20,
    "sort_by": "submittedDate",
    "default_format": "markdown"
  },
  "output": {
    "directory": "~/Documents/papers",
    "auto_organize": true
  }
}
```

## 🤝 贡献指南

欢迎贡献代码、报告问题或提出建议！

### 开发环境设置
```bash
# 克隆仓库
git clone https://github.com/yourusername/paper-search.git
cd paper-search

# 安装开发依赖
pip install -r requirements-dev.txt

# 运行测试
python -m pytest tests/
```

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙏 致谢

- [arXiv API](https://arxiv.org/help/api) - 提供论文搜索服务
- [Crossref API](https://www.crossref.org/) - 提供DOI解析服务
- [OpenClaw](https://openclaw.ai) - 提供技能框架

---

**Happy researching!** 🎓📚
