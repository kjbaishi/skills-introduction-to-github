#!/usr/bin/env python3
"""
测试搜索功能
"""

import sys
import os
import unittest
from unittest.mock import patch, Mock

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.search_arxiv import search_arxiv, parse_arguments

class TestSearchArxiv(unittest.TestCase):
    """测试arXiv搜索功能"""
    
    def test_parse_arguments(self):
        """测试参数解析"""
        # 测试基本参数
        test_args = [
            "--query", "machine learning",
            "--max-results", "5",
            "--format", "json"
        ]
        
        args = parse_arguments(test_args)
        self.assertEqual(args.query, "machine learning")
        self.assertEqual(args.max_results, 5)
        self.assertEqual(args.format, "json")
        
        # 测试默认值
        test_args = ["--query", "test"]
        args = parse_arguments(test_args)
        self.assertEqual(args.max_results, 10)  # 默认值
        self.assertEqual(args.format, "text")   # 默认值
    
    @patch('scripts.search_arxiv.requests.get')
    def test_search_arxiv_success(self, mock_get):
        """测试成功搜索"""
        # 模拟API响应
        mock_response = Mock()
        mock_response.content = """<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <title>Test Paper Title</title>
    <id>http://arxiv.org/abs/1234.56789v1</id>
    <published>2024-01-01T00:00:00Z</published>
    <summary>Test paper summary.</summary>
    <author><name>Author One</name></author>
    <author><name>Author Two</name></author>
    <category term="cs.LG" scheme="http://arxiv.org/schemas/atom"/>
  </entry>
</feed>"""
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        # 执行搜索
        results = search_arxiv("test query", max_results=1)
        
        # 验证结果
        self.assertEqual(len(results), 1)
        paper = results[0]
        self.assertEqual(paper['title'], "Test Paper Title")
        self.assertEqual(paper['id'], "http://arxiv.org/abs/1234.56789v1")
        self.assertEqual(len(paper['authors']), 2)
        self.assertIn("Author One", paper['authors'])
        self.assertIn("cs.LG", paper['categories'])
    
    @patch('scripts.search_arxiv.requests.get')
    def test_search_arxiv_empty(self, mock_get):
        """测试空结果"""
        # 模拟空响应
        mock_response = Mock()
        mock_response.content = """<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
</feed>"""
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        results = search_arxiv("nonexistent query", max_results=1)
        self.assertEqual(len(results), 0)
    
    def test_search_parameters(self):
        """测试搜索参数"""
        # 测试排序参数
        results = search_arxiv("test", sort_by="submittedDate", sort_order="ascending")
        # 这里主要是验证函数能正常调用，不验证具体结果
    
    @patch('scripts.search_arxiv.requests.get')
    def test_search_error(self, mock_get):
        """测试搜索错误"""
        mock_get.side_effect = Exception("Network error")
        
        # 应该返回空列表而不是抛出异常
        results = search_arxiv("test query")
        self.assertEqual(len(results), 0)

class TestOutputFormats(unittest.TestCase):
    """测试输出格式"""
    
    def test_text_format(self):
        """测试文本格式输出"""
        # 这里可以添加格式测试
        pass
    
    def test_json_format(self):
        """测试JSON格式输出"""
        # 这里可以添加格式测试
        pass

if __name__ == '__main__':
    unittest.main()