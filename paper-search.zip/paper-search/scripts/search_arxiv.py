#!/usr/bin/env python3
"""
arXiv论文搜索脚本
使用arXiv API搜索学术论文
"""

import argparse
import requests
import xml.etree.ElementTree as ET
from datetime import datetime
import json
import sys

# arXiv API基础URL
ARXIV_API_URL = "http://export.arxiv.org/api/query"

def search_arxiv(query, max_results=10, start=0, sort_by="relevance", sort_order="descending"):
    """
    搜索arXiv论文
    
    参数:
    - query: 搜索查询字符串
    - max_results: 最大结果数量 (默认10)
    - start: 起始位置 (默认0)
    - sort_by: 排序方式 ("relevance", "lastUpdatedDate", "submittedDate")
    - sort_order: 排序顺序 ("ascending", "descending")
    
    返回:
    - 论文列表 (字典列表)
    """
    
    # 构建查询参数
    params = {
        "search_query": query,
        "start": start,
        "max_results": max_results,
        "sortBy": sort_by,
        "sortOrder": sort_order
    }
    
    try:
        # 发送请求
        response = requests.get(ARXIV_API_URL, params=params)
        response.raise_for_status()
        
        # 解析XML响应
        root = ET.fromstring(response.content)
        
        # 定义XML命名空间
        ns = {
            'atom': 'http://www.w3.org/2005/Atom',
            'arxiv': 'http://arxiv.org/schemas/atom'
        }
        
        papers = []
        
        # 提取论文信息
        for entry in root.findall('atom:entry', ns):
            paper = {}
            
            # 标题
            title_elem = entry.find('atom:title', ns)
            paper['title'] = title_elem.text.strip() if title_elem is not None and title_elem.text else "无标题"
            
            # 摘要
            summary_elem = entry.find('atom:summary', ns)
            paper['abstract'] = summary_elem.text.strip() if summary_elem is not None and summary_elem.text else "无摘要"
            
            # 作者
            authors = []
            for author_elem in entry.findall('atom:author', ns):
                name_elem = author_elem.find('atom:name', ns)
                if name_elem is not None and name_elem.text:
                    authors.append(name_elem.text.strip())
            paper['authors'] = authors
            
            # arXiv ID
            id_elem = entry.find('atom:id', ns)
            if id_elem is not None and id_elem.text:
                # 提取arXiv ID，例如: http://arxiv.org/abs/2101.12345v1 -> 2101.12345
                arxiv_id = id_elem.text.split('/')[-1]
                paper['arxiv_id'] = arxiv_id
                paper['url'] = f"https://arxiv.org/abs/{arxiv_id.split('v')[0]}"
                paper['pdf_url'] = f"https://arxiv.org/pdf/{arxiv_id.split('v')[0]}.pdf"
            
            # 分类
            categories = []
            for category_elem in entry.findall('atom:category', ns):
                term = category_elem.get('term')
                if term:
                    categories.append(term)
            paper['categories'] = categories
            
            # 发布日期
            published_elem = entry.find('atom:published', ns)
            if published_elem is not None and published_elem.text:
                paper['published'] = published_elem.text
            
            # 更新日期
            updated_elem = entry.find('atom:updated', ns)
            if updated_elem is not None and updated_elem.text:
                paper['updated'] = updated_elem.text
            
            papers.append(paper)
        
        return papers
    
    except requests.exceptions.RequestException as e:
        print(f"网络请求错误: {e}", file=sys.stderr)
        return []
    except ET.ParseError as e:
        print(f"XML解析错误: {e}", file=sys.stderr)
        return []

def print_papers(papers, format='text'):
    """打印论文信息"""
    
    if format == 'json':
        print(json.dumps(papers, indent=2, ensure_ascii=False))
        return
    
    for i, paper in enumerate(papers, 1):
        print(f"\n{'='*60}")
        print(f"论文 #{i}")
        print(f"{'='*60}")
        print(f"标题: {paper.get('title', 'N/A')}")
        print(f"作者: {', '.join(paper.get('authors', []))}")
        print(f"arXiv ID: {paper.get('arxiv_id', 'N/A')}")
        print(f"URL: {paper.get('url', 'N/A')}")
        print(f"PDF: {paper.get('pdf_url', 'N/A')}")
        print(f"分类: {', '.join(paper.get('categories', []))}")
        
        if 'published' in paper:
            published_date = paper['published'][:10]  # 只取日期部分
            print(f"发布日期: {published_date}")
        
        # 摘要（前200字符）
        abstract = paper.get('abstract', '')
        if len(abstract) > 200:
            abstract = abstract[:200] + "..."
        print(f"摘要: {abstract}")
        
        print(f"{'-'*60}")

def main():
    parser = argparse.ArgumentParser(description="arXiv论文搜索工具")
    parser.add_argument("--query", "-q", required=True, help="搜索查询字符串")
    parser.add_argument("--max-results", "-n", type=int, default=10, help="最大结果数量 (默认: 10)")
    parser.add_argument("--start", "-s", type=int, default=0, help="起始位置 (默认: 0)")
    parser.add_argument("--sort-by", choices=["relevance", "lastUpdatedDate", "submittedDate"], 
                       default="relevance", help="排序方式 (默认: relevance)")
    parser.add_argument("--sort-order", choices=["ascending", "descending"], 
                       default="descending", help="排序顺序 (默认: descending)")
    parser.add_argument("--format", choices=["text", "json"], default="text", 
                       help="输出格式 (默认: text)")
    parser.add_argument("--output", "-o", help="输出文件路径")
    
    args = parser.parse_args()
    
    # 执行搜索
    papers = search_arxiv(
        query=args.query,
        max_results=args.max_results,
        start=args.start,
        sort_by=args.sort_by,
        sort_order=args.sort_order
    )
    
    if not papers:
        print("未找到相关论文。", file=sys.stderr)
        sys.exit(1)
    
    # 输出结果
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            if args.format == 'json':
                json.dump(papers, f, indent=2, ensure_ascii=False)
            else:
                original_stdout = sys.stdout
                sys.stdout = f
                print_papers(papers, format=args.format)
                sys.stdout = original_stdout
        print(f"结果已保存到: {args.output}")
    else:
        print_papers(papers, format=args.format)
    
    print(f"\n找到 {len(papers)} 篇论文。")

if __name__ == "__main__":
    main()