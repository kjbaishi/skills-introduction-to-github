#!/usr/bin/env python3
"""
获取论文BibTeX引用格式
支持DOI和arXiv ID
"""

import argparse
import requests
import re
import sys

def get_bibtex_from_doi(doi):
    """通过DOI获取BibTeX引用"""
    
    # 清理DOI
    doi = doi.strip()
    
    # 尝试多个来源
    sources = [
        f"https://doi.org/{doi}",
        f"https://api.crossref.org/works/{doi}/transform/application/x-bibtex",
        f"https://dx.doi.org/{doi}"
    ]
    
    headers = {
        'Accept': 'application/x-bibtex',
        'User-Agent': 'Mozilla/5.0 (compatible; PaperSearch/1.0)'
    }
    
    for url in sources:
        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                content_type = response.headers.get('content-type', '')
                if 'bibtex' in content_type.lower() or 'text/plain' in content_type:
                    return response.text.strip()
        except requests.exceptions.RequestException:
            continue
    
    return None

def get_bibtex_from_arxiv(arxiv_id):
    """通过arXiv ID获取BibTeX引用"""
    
    # 清理arXiv ID
    arxiv_id = arxiv_id.strip()
    
    # 移除版本号
    if 'v' in arxiv_id:
        arxiv_id = arxiv_id.split('v')[0]
    
    try:
        # 使用arXiv API获取元数据
        url = f"http://export.arxiv.org/api/query?id_list={arxiv_id}"
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            # 解析XML获取论文信息
            import xml.etree.ElementTree as ET
            root = ET.fromstring(response.content)
            
            ns = {'atom': 'http://www.w3.org/2005/Atom'}
            entry = root.find('atom:entry', ns)
            
            if entry is not None:
                # 提取信息
                title_elem = entry.find('atom:title', ns)
                title = title_elem.text.strip() if title_elem is not None else "Unknown Title"
                
                authors = []
                for author_elem in entry.findall('atom:author', ns):
                    name_elem = author_elem.find('atom:name', ns)
                    if name_elem is not None:
                        authors.append(name_elem.text.strip())
                
                published_elem = entry.find('atom:published', ns)
                year = published_elem.text[:4] if published_elem is not None else "2024"
                
                # 生成BibTeX
                bibtex = f"""@article{{{arxiv_id},
  title = {{{title}}},
  author = {{{' and '.join(authors)}}},
  year = {{{year}}},
  eprint = {{{arxiv_id}}},
  archivePrefix = {{arXiv}},
  primaryClass = {{cs.LG}}
}}"""
                
                return bibtex
    
    except Exception as e:
        print(f"获取arXiv BibTeX时出错: {e}", file=sys.stderr)
    
    return None

def generate_bibtex(identifier, entry_type="article"):
    """生成基本的BibTeX条目"""
    
    # 生成引用键
    if 'arxiv' in identifier.lower():
        cite_key = identifier.replace(':', '_').replace('/', '_')
    else:
        cite_key = identifier.replace('/', '_').replace('.', '_')
    
    bibtex = f"""@{entry_type}{{{cite_key},
  title = {{Unknown Title}},
  author = {{Unknown Author}},
  year = {{2024}},
  note = {{Identifier: {identifier}}}
}}"""
    
    return bibtex

def main():
    parser = argparse.ArgumentParser(description="获取论文BibTeX引用")
    parser.add_argument("--doi", help="论文DOI")
    parser.add_argument("--arxiv", help="论文arXiv ID")
    parser.add_argument("--identifier", "-i", help="论文标识符（自动检测类型）")
    parser.add_argument("--output", "-o", help="输出文件路径")
    
    args = parser.parse_args()
    
    # 确定标识符类型
    identifier = None
    identifier_type = None
    
    if args.doi:
        identifier = args.doi
        identifier_type = "doi"
    elif args.arxiv:
        identifier = args.arxiv
        identifier_type = "arxiv"
    elif args.identifier:
        identifier = args.identifier
        # 自动检测类型
        if identifier.startswith("10.") or "doi.org" in identifier:
            identifier_type = "doi"
        elif "arxiv" in identifier.lower() or re.match(r'\d{4}\.\d{4,5}', identifier):
            identifier_type = "arxiv"
        else:
            identifier_type = "unknown"
    else:
        print("错误：请提供论文标识符（--doi, --arxiv, 或 --identifier）", file=sys.stderr)
        sys.exit(1)
    
    # 获取BibTeX
    bibtex = None
    
    if identifier_type == "doi":
        bibtex = get_bibtex_from_doi(identifier)
    elif identifier_type == "arxiv":
        bibtex = get_bibtex_from_arxiv(identifier)
    
    # 如果获取失败，生成基本条目
    if not bibtex:
        print(f"警告：无法获取 {identifier} 的BibTeX，生成基本条目", file=sys.stderr)
        bibtex = generate_bibtex(identifier)
    
    # 输出结果
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(bibtex)
        print(f"BibTeX已保存到: {args.output}")
    else:
        print(bibtex)

if __name__ == "__main__":
    main()