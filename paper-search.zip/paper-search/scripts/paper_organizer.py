#!/usr/bin/env python3
"""
论文整理工具
将搜索结果整理成结构化格式
"""

import argparse
import json
import yaml
import csv
from datetime import datetime
import sys

def load_papers(input_file):
    """加载论文数据"""
    
    if input_file.endswith('.json'):
        with open(input_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    elif input_file.endswith('.yaml') or input_file.endswith('.yml'):
        with open(input_file, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    else:
        # 尝试自动检测格式
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            try:
                with open(input_file, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f)
            except:
                print(f"错误：无法解析文件格式 {input_file}", file=sys.stderr)
                sys.exit(1)

def organize_by_category(papers):
    """按分类整理论文"""
    
    organized = {}
    
    for paper in papers:
        categories = paper.get('categories', [])
        if not categories:
            categories = ['未分类']
        
        for category in categories:
            if category not in organized:
                organized[category] = []
            organized[category].append(paper)
    
    return organized

def organize_by_year(papers):
    """按年份整理论文"""
    
    organized = {}
    
    for paper in papers:
        # 提取年份
        year = "未知年份"
        
        if 'published' in paper:
            published = paper['published']
            if published and len(published) >= 4:
                year = published[:4]
        elif 'updated' in paper:
            updated = paper['updated']
            if updated and len(updated) >= 4:
                year = updated[:4]
        
        if year not in organized:
            organized[year] = []
        organized[year].append(paper)
    
    return organized

def export_to_markdown(papers, output_file, organization='category'):
    """导出为Markdown格式"""
    
    if organization == 'category':
        organized = organize_by_category(papers)
    elif organization == 'year':
        organized = organize_by_year(papers)
    else:
        organized = {'所有论文': papers}
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(f"# 论文整理报告\n\n")
        f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"论文总数: {len(papers)}\n\n")
        
        for category, category_papers in organized.items():
            f.write(f"## {category} ({len(category_papers)}篇)\n\n")
            
            for i, paper in enumerate(category_papers, 1):
                f.write(f"### {i}. {paper.get('title', '无标题')}\n\n")
                
                # 作者
                authors = paper.get('authors', [])
                if authors:
                    f.write(f"**作者**: {', '.join(authors)}\n\n")
                
                # arXiv ID和链接
                arxiv_id = paper.get('arxiv_id')
                if arxiv_id:
                    f.write(f"**arXiv ID**: {arxiv_id}\n")
                    f.write(f"**链接**: [{paper.get('url', '')}]({paper.get('url', '')})\n")
                    f.write(f"**PDF**: [{paper.get('pdf_url', '')}]({paper.get('pdf_url', '')})\n\n")
                
                # 分类
                categories = paper.get('categories', [])
                if categories:
                    f.write(f"**分类**: {', '.join(categories)}\n\n")
                
                # 发布日期
                if 'published' in paper:
                    f.write(f"**发布日期**: {paper['published'][:10]}\n\n")
                
                # 摘要
                abstract = paper.get('abstract', '')
                if abstract:
                    # 限制摘要长度
                    if len(abstract) > 300:
                        abstract = abstract[:300] + "..."
                    f.write(f"**摘要**: {abstract}\n\n")
                
                f.write("---\n\n")
        
        f.write("\n---\n")
        f.write("*使用 paper-search skill 生成*\n")

def export_to_csv(papers, output_file):
    """导出为CSV格式"""
    
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # 写入表头
        writer.writerow([
            '标题', '作者', 'arXiv ID', 'URL', 'PDF URL', 
            '分类', '发布日期', '更新日期', '摘要'
        ])
        
        # 写入数据
        for paper in papers:
            writer.writerow([
                paper.get('title', ''),
                '; '.join(paper.get('authors', [])),
                paper.get('arxiv_id', ''),
                paper.get('url', ''),
                paper.get('pdf_url', ''),
                '; '.join(paper.get('categories', [])),
                paper.get('published', '')[:10] if paper.get('published') else '',
                paper.get('updated', '')[:10] if paper.get('updated') else '',
                paper.get('abstract', '')[:500]  # 限制摘要长度
            ])

def export_to_json(papers, output_file):
    """导出为JSON格式"""
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(papers, f, indent=2, ensure_ascii=False)

def main():
    parser = argparse.ArgumentParser(description="论文整理工具")
    parser.add_argument("--input", "-i", required=True, help="输入文件路径 (JSON/YAML)")
    parser.add_argument("--output", "-o", required=True, help="输出文件路径")
    parser.add_argument("--format", "-f", choices=['markdown', 'csv', 'json'], 
                       default='markdown', help="输出格式 (默认: markdown)")
    parser.add_argument("--organization", choices=['category', 'year', 'none'], 
                       default='category', help="整理方式 (默认: category)")
    
    args = parser.parse_args()
    
    # 加载论文数据
    papers = load_papers(args.input)
    
    if not papers:
        print("错误：未找到论文数据", file=sys.stderr)
        sys.exit(1)
    
    print(f"加载了 {len(papers)} 篇论文", file=sys.stderr)
    
    # 导出为指定格式
    if args.format == 'markdown':
        export_to_markdown(papers, args.output, args.organization)
    elif args.format == 'csv':
        export_to_csv(papers, args.output)
    elif args.format == 'json':
        export_to_json(papers, args.output)
    
    print(f"论文已整理并保存到: {args.output}", file=sys.stderr)

if __name__ == "__main__":
    main()